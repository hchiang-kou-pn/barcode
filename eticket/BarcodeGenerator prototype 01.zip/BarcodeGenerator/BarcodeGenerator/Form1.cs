using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BarcodeGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void DrawBarcode(BarcodeSymbology symbology)
        {
            
            //using (Graphics g = pictureBox1.CreateGraphics())
            //{
            //    g.Clear(Color.White);
            //    bc.Draw(g, 0, 100, 400, 60);
            //}
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            DrawBarcode(new Code128Symbology());
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.PageUnit = GraphicsUnit.Inch;
            Barcode bc2 = new Barcode(new Code128Symbology(), new SizeF(2.125f, 0.4f)); // useNumericCompression

            ///////////////////// Print Barcode ///////////////////////////////////
            float fy = 1f;
            float offy = 0.4f;
            float fx = 0.5f;
            float offx = 0.15f;
            float hi = 0.22f;

            Bitmap image2 = new Bitmap(300, 60);
            string str = "01234567891234567";
            PointF pt = new PointF(fx, fy);
            bc2.Draw(e.Graphics, pt, str);
            Brush brush = Brushes.Black;
            pt = new PointF(fx+offx, fy+offy);
            FontFamily ff = new FontFamily("Arial");
            Font ft = new Font(ff, 8, FontStyle.Regular);
            e.Graphics.DrawString(str, ft, brush, pt);

            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            ////////////////////////////////////////////////////////////////////////////
            string title = "NEIGHBORHOOD";
            float offneigx = 2.2f;
            RectangleF rcf = new RectangleF(fx+offneigx, fy, 1.5f, hi);
            Font ftitle = new Font(ff, 10, FontStyle.Bold);
            e.Graphics.DrawString(title, ftitle, brush, rcf, sf);
            ////////////////////////////////////////////////////////////////////////////
            string section = "SECTION";
            float offsectionx = 3.5f;
            rcf = new RectangleF(fx+offsectionx, fy, 1.2f, hi);
            e.Graphics.DrawString(section, ftitle, brush, rcf, sf);
            ////////////////////////////////////////////////////////////////////////////
            string row = "ROW";
            float offrowx = 4.3f;
            PointF prow = new PointF(fx + offrowx, fy);
            rcf = new RectangleF(fx + offrowx, fy, 1.0f, hi);
            e.Graphics.DrawString(row, ftitle, brush, rcf, sf);
            ////////////////////////////////////////////////////////////////////////////
            string seat = "SEAT";
            float offseatx = 5.0f;
            rcf = new RectangleF(fx + offseatx, fy, 1.0f, hi);
            e.Graphics.DrawString(seat, ftitle, brush, rcf, sf);
            ////////////////////////////////////////////////////////////////////////////
            fy = 1.2f;

            string dadm = "Admission";
            Font fdata = new Font(ff, 10, FontStyle.Regular);
            rcf = new RectangleF(fx + offneigx, fy, 1.2f, hi);
            e.Graphics.DrawString(dadm, fdata, brush, rcf, sf);
            ////////////////////////////////////////////////////////////////////////////
            string dsection = "124";
            rcf = new RectangleF(fx + offsectionx, fy, 1.0f, hi);
            e.Graphics.DrawString(dsection, fdata, brush, rcf, sf);
            ////////////////////////////////////////////////////////////////////////////
            string drow = "8";
            rcf = new RectangleF(fx + offrowx, fy, 1.0f, hi);
            e.Graphics.DrawString(drow, fdata, brush, rcf, sf);
            ////////////////////////////////////////////////////////////////////////////
            string dseat = "2";
            rcf = new RectangleF(fx + offseatx, fy, 1.0f, hi);
            e.Graphics.DrawString(dseat, fdata, brush, rcf, sf);
            ////////////////////////////////////////////////////////////////////////////
            string dnoname = "HS";
            float offnonamex = 5.4f;
            rcf = new RectangleF(fx + offnonamex, fy, 1.0f, hi);
            e.Graphics.DrawString(dnoname, fdata, brush, rcf, sf);
            ///////////// Event Code ////////////////////////////////////////////////////
            string teventcode = "Event Code";
            offy = 0.40f;
            float xwide = 2.0f;
            rcf = new RectangleF(fx, fy + offy, xwide, hi);
            e.Graphics.DrawString(teventcode, ftitle, brush, rcf, sf);
            ///////////// Event Code ////////////////////////////////////////////////////
            string deventcode = "Event Code";
            offy = 0.6f;
            rcf = new RectangleF(fx, fy + offy, xwide, hi);
            e.Graphics.DrawString(deventcode, fdata, brush, rcf, sf);

            ///////////// price ////////////////////////////////////////////////////
            string tprice = "Price & All TAX";
            offy = 0.80f;
            rcf = new RectangleF(fx, fy + offy, xwide, hi);
            e.Graphics.DrawString(tprice, ftitle, brush, rcf, sf);
            ///////////// price ////////////////////////////////////////////////////
            string dprice = "$1,234.56";
            offy = 1.0f;
            rcf = new RectangleF(fx, fy + offy, xwide, hi);
            e.Graphics.DrawString(dprice, fdata, brush, rcf, sf);
            ///////////// Section row seat //////////////////////////////////////////////
            string tsrs = "Section / Row / Seat";
            offy = 1.20f;
            rcf = new RectangleF(fx, fy + offy, xwide, hi);
            e.Graphics.DrawString(tsrs, ftitle, brush, rcf, sf);
            ///////////// section row seat ////////////////////////////////////////////////////
            string dsrs = "123 / 8 / 2";
            offy = 1.4f;
            rcf = new RectangleF(fx, fy + offy, xwide, hi);
            e.Graphics.DrawString(dsrs, fdata, brush, rcf, sf);
            ///////////// price code //////////////////////////////////////////////
            string tpc = "Price Code";
            offy = 1.60f;
            rcf = new RectangleF(fx, fy + offy, xwide, hi);
            e.Graphics.DrawString(tpc, ftitle, brush, rcf, sf);
            ///////////// price code ////////////////////////////////////////////////////
            string dpc = "Price Code";
            offy = 1.8f;
            rcf = new RectangleF(fx, fy + offy, xwide, hi);
            e.Graphics.DrawString(dpc, fdata, brush, rcf, sf);
            ///////////// Event Line 1 - 6 ////////////////////////////////////////////////////
            fy = 1.6f;
            fx = 2.0f;
            xwide = 5.0f;
            string dl1 = "EVENT LINE 1";
            rcf = new RectangleF(fx, fy, xwide, hi);
            e.Graphics.DrawString(dl1, fdata, brush, rcf, sf);

            string dl2 = "EVENT LINE 2";
            rcf = new RectangleF(fx, fy+hi, xwide, hi);
            e.Graphics.DrawString(dl2, fdata, brush, rcf, sf);

            string dl3 = "EVENT LINE 3";
            rcf = new RectangleF(fx, fy + hi*2, xwide, hi);
            e.Graphics.DrawString(dl3, fdata, brush, rcf, sf);
            
            string dl4 = "EVENT LINE 4";
            rcf = new RectangleF(fx, fy + hi*3, xwide, hi);
            e.Graphics.DrawString(dl4, fdata, brush, rcf, sf);
            
            string dl5 = "EVENT LINE 5";
            rcf = new RectangleF(fx, fy + hi*4, xwide, hi);
            e.Graphics.DrawString(dl5, fdata, brush, rcf, sf);

            string dl6 = "EVENT LINE 6";
            rcf = new RectangleF(fx, fy + hi * 5, xwide, hi);
            e.Graphics.DrawString(dl6, fdata, brush, rcf, sf);

            string dl7 = "Day July 20, YYYY 6:00PM";
            rcf = new RectangleF(fx, fy + hi * 6, xwide, hi);
            e.Graphics.DrawString(dl7, fdata, brush, rcf, sf);

            ////////////// Rotate Barcode //////////////////////////////////
            e.Graphics.RotateTransform(90);

            float Rfy = -7.4f;
            float Rfx = 0.8f;
            float Roffy = 0.4f;
            float Roffx = 0.15f;

            PointF ptf = new PointF(Rfx, Rfy);
            bc2.Draw(e.Graphics, ptf, str);
            ptf = new PointF(Rfx+Roffx, Rfy + Roffy);
            e.Graphics.DrawString(str, ft, brush, ptf);
        }
            

        private void txtBarcode_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void txtBarcode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                printPreviewControl1.InvalidatePreview();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }
    }
}