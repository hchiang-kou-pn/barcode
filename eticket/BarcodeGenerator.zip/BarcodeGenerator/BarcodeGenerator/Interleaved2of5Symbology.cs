using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace BarcodeGenerator
{
    public class Interleaved2of5Symbology : BarcodeSymbology
    {
        #region MapData
        private static readonly SymbolMap<char> _charSet = new SymbolMap<char>();
        static Interleaved2of5Symbology()
        {
            _charSet.Add('0', 0, 0, 1, 1, 0);
            _charSet.Add('1', 1, 0, 0, 0, 1);
            _charSet.Add('2', 0, 1, 0, 0, 1);
            _charSet.Add('3', 1, 1, 0, 0, 0);
            _charSet.Add('4', 0, 0, 1, 0, 1);
            _charSet.Add('5', 1, 0, 1, 0, 0);
            _charSet.Add('6', 0, 1, 1, 0, 0);
            _charSet.Add('7', 0, 0, 0, 1, 1);
            _charSet.Add('8', 1, 0, 0, 1, 0);
            _charSet.Add('9', 0, 1, 0, 1, 0);
        }
        #endregion

        protected override int QuietLength
        {
            get { return 10; }
        }

        protected override void ProcessCode(string barcode)
        {
            Add(1, 0, 1, 0);

            if (barcode.Length % 2 != 0)
            {
                barcode = "0" + barcode;
            }

            for (int i = 0; i < barcode.Length - 1; i += 2)
            {
                byte[] bars1 = _charSet[barcode[i]];
                byte[] bars2 = _charSet[barcode[i + 1]];

                for (int j = 0; j < 5; j++)
                {
                    if (bars1[j] == 1)
                        Add(1, 1);
                    else
                        Add(1);

                    if (bars2[j] == 1)
                        Add(0, 0);
                    else
                        Add(0);
                }
            }

            Add(1, 1, 0, 1);
        }
    }

}
