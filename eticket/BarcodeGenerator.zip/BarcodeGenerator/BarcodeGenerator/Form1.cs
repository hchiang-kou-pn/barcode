using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BarcodeGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void DrawBarcode(BarcodeSymbology symbology)
        {
            
            //using (Graphics g = pictureBox1.CreateGraphics())
            //{
            //    g.Clear(Color.White);
            //    bc.Draw(g, 0, 100, 400, 60);
            //}
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            DrawBarcode(new Code128Symbology());
        }

        private void btn2of5_Click(object sender, EventArgs e)
        {
            DrawBarcode(new Interleaved2of5Symbology());
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.PageUnit = GraphicsUnit.Inch;

            Barcode bc1 = new Barcode(new Code128Symbology(false), new SizeF(0.4f, 2.125f), BarcodeOrientation.Vetical);
            Barcode bc2 = new Barcode(new Code128Symbology(), new SizeF(2.125f, 0.4f));
            Barcode bc3 = new Barcode(new Interleaved2of5Symbology(), new SizeF(2.125f, 0.4f));

            //Bitmap image1 = new Bitmap(300, 60);
           // Bitmap image2 = new Bitmap(300, 60);
            //Bitmap image3 = new Bitmap(300, 60);
            //using (Graphics g = Graphics.FromImage(image1))
            //{
            //    bc1.Draw(g, 0, 0, 300, 60);
            //}
            //using (Graphics g = Graphics.FromImage(image2))
            //{
            //    bc2.Draw(g, 0, 0, 300, 60);
            //}
            //using (Graphics g = Graphics.FromImage(image3))
            //{
            //    bc3.Draw(g, 0, 0, 300, 60);
            //}

            //e.Graphics.DrawImageUnscaled(image1, 100, 100);
            //e.Graphics.DrawImageUnscaled(image2, 100, 180);
            //e.Graphics.DrawImageUnscaled(image3, 100, 260);

            bc1.Draw(e.Graphics, 1f, 1f, txtBarcode.Text);
            bc2.Draw(e.Graphics, 4f, 2f, txtBarcode.Text);
            bc3.Draw(e.Graphics, 4f, 3f, txtBarcode.Text);
        }

        private void txtBarcode_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void txtBarcode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                printPreviewControl1.InvalidatePreview();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }
    }
}